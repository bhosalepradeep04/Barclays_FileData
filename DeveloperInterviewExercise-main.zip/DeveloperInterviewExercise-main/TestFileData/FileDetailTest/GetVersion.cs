﻿using FileData.Interfaces;
using FileData;
using System;
using System.Collections.Generic;
using System.Text;
using Xunit;

namespace TestFileData.FileDetailTest
{
    public class GetVersion
    {
        private readonly IFileDetail fileDetail;

        public GetVersion()
        {
            this.fileDetail = new FileDetail();
        }

        [Fact]
        [Trait("FileDetail", nameof(GetVersion))]
        public void WhenGetVersion_WithZeroArguments_ShouldThrowArgumentException()
        {
            // Arrange
            string[] args = new string[] { };

            // Act
            Exception ex = Assert.Throws<ArgumentException>(() => this.fileDetail.GetVersion(args));

            // Assert
            Assert.NotNull(ex);
            Assert.Equal(typeof(ArgumentException), ex.GetType());
            Assert.Equal(string.Format("Invalid input: There should be atleast 1 argument!"), ex.Message);
        }
    }
}
