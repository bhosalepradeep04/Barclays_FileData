﻿namespace FileData
{
    using FileData.Constants;
    using FileData.Interfaces;
    using System;
    using ThirdPartyTools;

    /// <summary>
    /// Defines the <see cref="FileDetail" />.
    /// </summary>
    public class FileDetailPrototype : IFileDetail
    {
        /// <summary>
        /// Defines the _fileDetails.
        /// </summary>
        private readonly FileDetails _fileDetails = new FileDetails();

        /// <summary>
        /// The GetSize.
        /// </summary>
        /// <param name="args">The args<see cref="string[]"/>.</param>
        /// <returns>The <see cref="string"/>.</returns>
        public virtual void GetSize(string[] args)
        {
            throw new NotImplementedException();
        }

        /// <summary>
        /// The GetVersion.
        /// </summary>
        /// <param name="args">The args<see cref="string[]"/>.</param>
        /// <returns>The <see cref="string"/>.</returns>
        public virtual void GetVersion(string[] args)
        {
            if (args?.Length < 2)
            {
                throw new ArgumentException("Invalid input: There should be atleast 2 arguments!");
            }

            if (args[0].Equals(FileDetailConstants.Version, StringComparison.InvariantCultureIgnoreCase))
            {
                var version = this._fileDetails.Version(args[1]);
                Console.WriteLine($"Version: {version}");
            }
            else
            {
                throw new ArgumentException($"Invalid input: First argument has to be {FileDetailConstants.Version}!");
            }
        }
    }
}
