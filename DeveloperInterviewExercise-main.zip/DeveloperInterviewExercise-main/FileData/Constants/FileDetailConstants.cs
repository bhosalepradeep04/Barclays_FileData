﻿namespace FileData.Constants
{
    /// <summary>
    /// Defines the <see cref="FileDetailConstants" />.
    /// </summary>
    public static class FileDetailConstants
    {
        /// <summary>
        /// Defines the Version.
        /// </summary>
        public static readonly string Version = "-v";

        /// <summary>
        /// Defines the Versions.
        /// </summary>
        public static readonly string[] Versions = { "-v", "--v", "/v", "--version" };

        /// <summary>
        /// Defines the Sizes.
        /// </summary>
        public static readonly string[] Sizes = { "-s", "--s", "/s", "--size" };
    }
}
