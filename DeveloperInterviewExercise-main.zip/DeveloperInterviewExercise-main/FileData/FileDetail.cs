﻿namespace FileData
{
    using FileData.Constants;
    using System;
    using System.Linq;
    using ThirdPartyTools;

    /// <summary>
    /// Defines the <see cref="FileDetail" />.
    /// </summary>
    public class FileDetail : FileDetailPrototype
    {
        /// <summary>
        /// Defines the _fileDetails.
        /// </summary>
        private readonly FileDetails _fileDetails = new FileDetails();

        /// <summary>
        /// The GetSize.
        /// </summary>
        /// <param name="args">The args<see cref="string[]"/>.</param>
        public override void GetSize(string[] args)
        {
            if (args?.Length == 0)
            {
                throw new ArgumentException("Invalid input: There should be atleast 1 argument!");
            }

            if (FileDetailConstants.Sizes.ToList().Contains(args[0].ToLower()))
            {
                var size = this._fileDetails.Size(args[0]);
                Console.WriteLine($"Size: {size}");
            }
            else
            {
                throw new ArgumentException($"Invalid argument '{args[0]}' for size!");
            }
        }

        /// <summary>
        /// The GetVersion.
        /// </summary>
        /// <param name="args">The args<see cref="string[]"/>.</param>
        public override void GetVersion(string[] args)
        {
            if (args?.Length == 0)
            {
                throw new ArgumentException("Invalid input: There should be atleast 1 argument!");
            }

            if (FileDetailConstants.Versions.ToList().Contains(args[0].ToLower()))
            {
                var version = this._fileDetails.Size(args[0]);
                Console.WriteLine($"Version: {version}");
            }
            else
            {
                throw new ArgumentException($"Invalid argument '{args[0]}' for version!");
            }
        }
    }
}
