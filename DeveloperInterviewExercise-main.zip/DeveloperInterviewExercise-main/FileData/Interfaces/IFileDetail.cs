﻿namespace FileData.Interfaces
{
    /// <summary>
    /// Defines the <see cref="IFileDetail" />.
    /// </summary>
    public interface IFileDetail
    {
        /// <summary>
        /// The GetVersion.
        /// </summary>
        /// <param name="args">The args<see cref="string[]"/>.</param>
        void GetVersion(string[] args);

        /// <summary>
        /// The GetSize.
        /// </summary>
        /// <param name="args">The args<see cref="string[]"/>.</param>
        void GetSize(string[] args);
    }
}
